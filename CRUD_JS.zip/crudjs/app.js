const { NOMEM } = require('dns');
const e = require('express');
const express = require('express');
const app = express();
const path = require('path');
const sqlite3 = require('sqlite3').verbose();

const db = new sqlite3.Database('./database/db.sqlite',(err) => {
    if(err){
        console.error('Erro ao conectar ao banco de dados.', err.message);
    }else{
        console.log('Conectado ao banco de dados Sqlite.');
        // criar tabela do banco de dados caso ela não exista
        db.run(`
                    CREATE TABLE IF NOT EXISTS jogos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome TEXT NOT NULL,
                    plataforma TEXT NOT NULL,
                    genero TEXT NOT NULL    
            )`);
    }
});

// configuração do EJS 
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json()); // modificado aqui o lugar com o deep seek
app.use(express.urlencoded({extended: true}));

//Rotas
app.get('/', (req,res) => {
    res.render('index');
});

app.get('/operacoes',(req,res) => {
    res.render('operacoes');
});

app.get('/sobre',(req,res) => {
    res.render('sobre');
});

// Create CRUD
app.post('/criar',(req,res) => {
    const {nome,plataforma,genero} = req.body;
    db.run(
        `INSERT INTO jogos(nome, plataforma, genero) VALUES(?,?,?)`,
        [nome, plataforma, genero],
        (err) => {
            if(err){
                return res.status(500).send('Erro ao criar o registro.');
            }else{
                res.redirect('/operacoes');
            }
        }
    );
});

//read

app.get(`/buscar/:id`, (req, res) => {
    const id = req.params.id; // modificado aqui no deepseek
    db.get(`SELECT * FROM jogos WHERE id = ?`, [id], (err, row) => {
        if(err){
            return res.status(500).send('Erro ao buscar o registro');
        }else{
            res.json(row);
        }
    });
});


//Middleware para processar JSON no corpo da requisição


//Update
app.post('/alterar/:id', (req,res) => {
    const {id} = req.params;
    const {nome, plataforma, genero} = req.body;
    //verifica se pelo menos um campo foi preenchido
    if(!nome && !plataforma & !genero){
        return res.status(400).json({message: 'Preencha ao menos um campo.'});
    }
    //monta a query dinamicamente com base nso campos preenchidos
    let query = 'UPDATE jogos SET ';
    const params = [];
    if(nome){
        query += 'nome = ?,';
        params.push(nome);
    }
    if(plataforma){
        query += 'plataforma = ?,';
        params.push(plataforma);
    }

    if(genero){
        query += 'genero = ?,';
        params.push(genero);
    }
    //remove a última vírgula
    query = query.slice(0, -1);
    query += ' WHERE id = ?';
    params.push(id);

//executamos a query
    db.run(
        query,params, function(err){
            if(err){
                console.error('Erro ao executar a query', err.message);
                return res.status(500).send('Erro ao alterar o registro');
            }
            if(this.changes === 0){
                return res.status(404).json({message: 'Registro não encontrado.'});
            }
            res.json({sucess: true, message: 'Registro alterado com sucesso.'});
        }
    );
});

//Delete
app.post('/deletar/:id', (req, res) => {
    const {id} = req.params;
    db.run(`DELETE FROM jogos WHERE id = ?`, [id], function(err){
        if(err){
            return res.status(500).send('Erro ao deletar o registro');
        }
        res.json({sucess: true, message: 'Registro deletado com sucesso!'})
    });
});

//Iniciando o servidor
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
