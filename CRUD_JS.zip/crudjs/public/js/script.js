const { response } = require("express");

function buscarRegistro(){
    const id = document.getElementById('searchId').value;
    fetch(`/buscar/${id}`)
    .then(response => response.json())
    .then(data => {
        const resultDiv = document.getElementById('searchResult');
        if(data){
            resultDiv.innerHTML = `ID: ${data.id}, Nome: ${data.nome}, Plataforma: ${data.plataforma}, Gênero: ${data.genero}`;
        }else{
            resultDiv.innerHTML = 'Registro não encontrado.';
        }
    });
}

function alterarRegistro(){
    const id = document.getElementById('updateId').value;
    const nome = document.getElementById('updateNome').value;
    const plataforma = document.getElementById('updatePlataforma').value;
    const genero = document.getElementById('updateGenero').value;
    if(!nome && !plataforma && !genero){
        alert('Preencha ao menos um campo.');
        return;
    }
    fetch(`/alterar/${id}`,{
        method: 'POST',
        headers:{
            'Content-Type':'application/json'
        },
        body: JSON.stringify({nome,plataforma,genero}),
    })
    .then(response => response.json())
    .then(data => {
        if(data.sucess){
            alert('Registro alterado com sucesso.');
            window.location.reload();
        }else{
            alert('Erro ao alterar registro.' + data.message);
        }
    })
    .catch(erro => console.error('Erro:', error));
}

function deletarRegistro(){
    const id = document.getElementById('deleteId').value;
    fetch(`/deletar/${id}`, {
        method: 'POST',
    })
    .then(response => response.json())
    .then(data => {
        if(data.sucess){
            alert('Registro deletado com sucesso.');
            window.location.reload();
        }else{
            alert('Erro ao deletar registro.' + data.message);
        }
        
    })
    .catch(error => {console.error('erro:', error);
    });
    
}